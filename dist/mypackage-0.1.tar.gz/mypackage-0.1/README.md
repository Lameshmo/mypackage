# mypackage
This library was created as an example of how to publish own python package.

# Building this package locally.
"python setup.py sdist"

## Installing this package from GitHub
"pip install git+http://github.com/Motseki-Khoarai/example-python-package.git"

## Updating this package from GitHub
"pip install --upgrade git+http://github.com/Motseki-Khoarai/example-python-package.git"